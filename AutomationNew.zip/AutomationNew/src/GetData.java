
import java.sql.*;
public class GetData {
	public static String getTable(String query){
		String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
		String DB_URL = "jdbc:mysql://localhost/TEST";
		String USER = "root";
		String PASS = "!Ramya1992";
		Connection conn = null;
		Statement stmt = null;

		try{
		   //STEP 2: Register JDBC driver
		   Class.forName("com.mysql.jdbc.Driver");

		   //STEP 3: Open a connection
		   System.out.println("Connecting to database...");
		   conn = DriverManager.getConnection(DB_URL,USER,PASS);

		   //STEP 4: Execute a query
		   System.out.println("Creating statement...");
		   stmt = conn.createStatement();
		   String sql;
		   sql = "SELECT id, first, last, age FROM Employees WHERE age > "+query;
		   ResultSet rs = stmt.executeQuery(sql);
		   
				StringBuffer sb = new StringBuffer("<table border=1><tr><th>EMP_ID</th><th>FIRST NAME</th><th>LAST NAME</th><th>AGE</th></tr>");
				while(rs.next()) {
				      sb.append("<tr>");
				      ResultSetMetaData rsmd = rs.getMetaData();
				      int totFields = rsmd.getColumnCount();
				      for(int cnt = 1; cnt <= totFields; cnt++){
				           
				      sb.append("<td>").append(rs.getString(cnt)).append("    ").append("</td>");
				      
				      }
				      
				      //System.out.println("jsonObjEachRow : " + sb.toString());
				      sb.append("</tr>");
				}
				sb.append("</table>");	
		   rs.close();
		   stmt.close();
		   conn.close();
		   return sb.toString();
		   
		}catch(SQLException se){
		   //Handle errors for JDBC
		   se.printStackTrace();
		}catch(Exception e){
		   //Handle errors for Class.forName
		   e.printStackTrace();
		}finally{
		   //finally block used to close resources
		   try{
		      if(stmt!=null)
		         stmt.close();
		   }catch(SQLException se2){
		   }// nothing we can do
		   try{
		      if(conn!=null)
		         conn.close();
		   }catch(SQLException se){
		      se.printStackTrace();
		   }//end finally try
		}//end try
		return null;
	}

}
